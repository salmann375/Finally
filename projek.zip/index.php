<!DOCTYPE html>
<html>
<head>
<title>Finally | Homepage</title>
</head>
<body>
<h1> Finally | Platform Penemuan dan Kehilangan Barang </h1>
<a href="login_user.php">User</a><br>
<a href="admin_login.php">Admin</a><br>
</body>