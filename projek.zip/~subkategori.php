perlengkapan kuliah
	<select name="subkategori" required>
	<option value="">Subkategori</option>
	<option value="buku">Buku</option>
	<option value="binder">Binder</option>
	<option value="kotak_pensil">Kotak Pensil</option>
	<option value="tas">Tas</option>

Lainnya
	<select name="subkategori" required>
	<option value="">Subkategori</option>
	<option value="kartu_atm">Kartu ATM</option>
	<option value="dompet">Dompet</option>
	<option value="jam_tangan">Jam Tangan</option>
	<option value="jaket">Jaket</option>
	<option value="kamera">Kamera</option>
	<option value="kotak_pensil">Kotak Pensil</option>
	<option value="kunci">Kunci</option>
	<option value="motor">Motor</option>
	<option value="sepatu">Sepatu</option>