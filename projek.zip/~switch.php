		<p>
			<label for="fakultas">Fakultas: </label><br>
			<select name="fakultas">
			<option value="">Fakultas</option>
			<option value="Fakultas Pertanian">A - Faperta</option>
			<option value="Fakultas Kedokteran Hewan">B - FKH</option>
			<option value="Fakultas Perikanan dan Ilmu Kelautan">C - FPIK</option>
			<option value="Fakultas Peternakan">D - Fapet</option>
			<option value="Fakultas Kehutanan">E - Fahutan</option>
			<option value="Fakultas Teknologi Pertanian">F - Fateta</option>
			<option value="Fakultas Matematika dan Ilmu Pengetahuan Alam">G - FMIPA</option>
			<option value="fFakultas Ekonomi dan Manajemen">H - FEM</option>
			<option value="Fakultas Ekologi Manusia">I - FEMA</option>
			<option value="Program Pendidikan Kompetensi Umum">PPKU</option>
			</select>
		</p>
		<p>
			<label for="prodi">Program Studi: </label><br>
			<select name="prodi">
			<option value="">Program Studi</option>
			<option value="Ilmu Tanah dan Sumberdaya Lahan">A1 - TSL</option>
			<option value="Agronomi dan Hortikultura">A2 - AGH</option>
			<option value="Proteksi Tanaman">A3 - PTN</option>
			<option value="Arsitektur Lanskap">A4 - ARL</option>
			<option value="Kedokteran Hewan">B0 - FKH</option>
			<option value="Budidaya Perairan">C1 - BDP</option>
			<option value="Manajemen Sumberdaya Perairan">C2 - MSP</option>
			<option value="Teknologi Hasil Perairan">C3 - THP</option>
			<option value="Pemanfaatan Sumberdaya Perikanan">C4 - PSP</option>
			<option value="Ilmu dan Teknologi Kelautan">C5 - ITK</option>
			<option value="Ilmu Produksi dan Teknologi Peternakan">D1 - IPTP</option>
			<option value="Ilmu Nutrisi dan Teknologi Pakan">D2 - INTP</option>
			<option value="Teknologi Hasil Ternak">D3 - THT</option>
			<option value="Manajemen Hutan">E1 - MNH</option>
			<option value="Teknologi Hasil Hutan">E2 - THH</option>
			<option value="Konservasi Sumberdaya Hutan dan Ekowisata">E3 - KSH</option>
			<option value="Silvikultur">E4 - SVK</option>
			<option value="Teknik Pertanian dan Biosistem">F1 - TPB</option>
			<option value="Ilmu dan Teknologi Pangan">F2 - ITP</option>
			<option value="Teknologi Industri Pertanian">F3 - TIN</option>
			<option value="Teknik Sipil dan Lingkungan">F4 - SIL</option>
			<option value="Statistika">G1 - STK</option>
			<option value="Meteorologi Terapan">G2 - GFM</option>
			<option value="Biologi">G3 - BIO</option>
			<option value="Kimia">G4 - KIM</option>
			<option value="Matematika">G5 - MAT</option>
			<option value="Ilmu Komputer">G6 - KOM</option>
			<option value="Fisika">G7 - FIS</option>
			<option value="Biokimia">G8 - BIK</option>
			<option value="Aktuaria">G9 - AKT</option>
			<option value="Ilmu Ekonomi">H1 - IE</option>
			<option value="Manajemen">H2 - MAN</option>
			<option value="Agribisnis">H3 - AGB</option>
			<option value="Ekonomi Sumberdaya Lingkungan">H4 - ESL</option>
			<option value="Ekonomi Syariah">H5 - EKS</option>
			<option value="Gizi Masyarakat">I1 - GIZ</option>
			<option value="Ilmu Keluarga dan Konsumen">I2 - IKK</option>
			<option value="Sains Komunikasi dan Pengembangan Masyarakat">I3 - KPM</option>
			<option value="Program Pendidikan Kompetensi Umum">PPKU</option>
			</select>
		</p>