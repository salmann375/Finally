<form class="pure-form">
    <fieldset>
    <script src="js/pass.js"></script>
        <legend>Confirm password with HTML5</legend>
        <input type="password" placeholder="Password" id="password" required>
        <input type="password" placeholder="Confirm Password" id="password1">
        <button type="submit" class="pure-button pure-button-primary">Confirm</button>
    <script src="js/pass.js"></script>
	</fieldset>
</form>