
<h2>Klaim</h2><br>
	<table border="1">
	<thead>
		<tr>
			<th>Judul</th>
			<th>Foto</th>
			<th>Waktu Ambil</th>
			<th>Tindakan</th>
		</tr>
	</thead>
	<tbody>
		<?php
		$quer = "SELECT 'k.uname', 'k.waktu_ambil', 'k.id_barang', 'b.id', 'b.id_lp', 'lp.id', 'lp.judul', 'lp.foto'                     FROM klaim k, barang b, laporan_penemuan lp WHERE 'k.uname' == '$aktif' AND 'k.id_barang' == 'b.id' AND 'b.id_lp' == 'lp.id'";
		$query = mysqli_query($connect, $quer);
		while($view = mysqli_fetch_array($query)){
			$loc = $view['lp.foto'];
			echo "<tr>";

			echo "<td>".$view['lp.judul']."</td>";
			echo "<td>"."<img class='image-style' src=".$loc.">"."</td>";

			}
		?>
	</tbody>
	</table>