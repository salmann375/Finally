<form action="kirimpass.php" method="post">
<table border="0">
<tbody>
<tr>
<td>Masukkan Username Anda</td>
<td>
<input name="uname" type="text" /></td>
</tr>
<tr>
<td></td>
<td>
<input name="Submit" type="submit" value="Submit" /></td>
</tr>
</tbody></table>
</form>