<?php
$server='localhost'; 										
$username='root';    									
$password='';												
$database='finally';									
$connect=mysqli_connect($server, $username, $password, $database);
?>