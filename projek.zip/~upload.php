<?php 
include("config.php");

if(isset($_POST['btn'])){
	$name = $_FILES['myfile']['name'];
	$type = $_FILES['myfile']['type'];
	$data = file_get_contents($_FILES['myfile']['tmp_name']);
}

	$query = mysqli_query($connect, "INSERT INTO image (nama_gambar, mime, gambar) VALUEs ('$name', '$type', '$data')");

?>

<!DOCTYPE html>
<html>
<head>
	<title>Finally | Laporan</title>
</head>
<body>
	<header>
		<b><h3>Laporan Kehilangan</h3></b>
	</header>
	<form method="POST" enctype="multipart/form-data">
		<input type="file" name="myfile"> 	
		<button name=""btn>Upload</button>
	</form>

