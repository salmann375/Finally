<?php
include('config.php');
$uname = $_GET['uname'];
$query = mysqli_query($connect, "SELECT uname, nama_lengkap, email, nohp, status FROM akun WHERE uname = $uname");
while ($view_akun = mysqli_fetch_array($query)){
	$uname = $view_akun['uname'];
	$nama_lengkap = $view_akun['nama_lengkap'];
	$email = $view_akun['email'];
	$nohp = $view_akun['nohp'];
	$status = $view_akun['status'];
}
?>
<h3><?php echo $uname ?></h3>
<?php echo "<a href = ~view_profil.php?uname=$uname>Profil</a>"?><br>
<table border="1">
	<thead>
		<tr>
			<th>Username</th>
			<th>Nama Lengkap</th>
			<th>Email</th>
			<th>Nomor Telepon</th>
			<th>Status</th>
		</tr>
	</thead>
	<tbody>
		<?php
			echo "<tr>";

			echo "<td>".$uname."</td>";
			echo "<td>".$nama_lengkap."</td>";
			echo "<td>".$email."</td>";
			echo "<td>".$nohp."</td>";
			echo "<td>".$status."</td>";
			echo "</tr>";
		?>
	</tbody>